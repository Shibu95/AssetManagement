﻿using Foundation;
using UIKit;

namespace TrainingAssetManagement;

[Register("AppDelegate")]
public class AppDelegate : MauiUIApplicationDelegate
{
	private const string MutexName = "MauiBlazorHybridApp_Mutex";
	private static Mutex? _mutex;
	protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();
	public override bool FinishedLaunching(UIApplication application, NSDictionary launchOptions)
	{
		bool isNewInstance;
		_mutex = new Mutex(true, MutexName, out isNewInstance);

		if (!isNewInstance)
		{
			Console.WriteLine("Another instance is already running.");
			// On macOS Catalyst, Environment.Exit works to terminate the app
			Environment.Exit(0);
			return false;
		}

		return base.FinishedLaunching(application, launchOptions);
	}
}

