﻿using Microsoft.UI.Xaml;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using WinRT.Interop;
using System.Runtime.InteropServices;
using System.Threading;

namespace TrainingAssetManagement.WinUI
{
	public partial class App : MauiWinUIApplication
	{
		private const string MutexName = "Global\\MauiBlazorHybridApp_Mutex_12345";
		private const string EventName = "Global\\MauiBlazorHybridApp_Event_12345";

		private static Mutex? _mutex;
		private static EventWaitHandle? _eventWaitHandle;

		// WinAPI imports to bring window to front
		[DllImport("user32.dll")]
		private static extern bool SetForegroundWindow(IntPtr hWnd);

		[DllImport("user32.dll")]
		private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

		private const int SW_RESTORE = 9;

		public App()
		{
			InitializeComponent();
		}

		protected override MauiApp CreateMauiApp() => MauiProgram.CreateMauiApp();

		protected override void OnLaunched(LaunchActivatedEventArgs args)
		{
			bool isNewInstance;
			_mutex = new Mutex(true, MutexName, out isNewInstance);
			_eventWaitHandle = new EventWaitHandle(false, EventResetMode.AutoReset, EventName);

			if (isNewInstance)
			{
				// First instance: start listener thread
				Thread listenerThread = new Thread(() =>
				{
					while (_eventWaitHandle.WaitOne())
					{
						BringToFront();
					}
				})
				{
					IsBackground = true
				};
				listenerThread.Start();

				base.OnLaunched(args);

				// Optional: maximize on first launch
				MaximizeWindow();
			}
			else
			{
				// Second instance: signal first instance to bring to front
				_eventWaitHandle.Set();
				Environment.Exit(0);
			}
		}

		private static void BringToFront()
		{
			var window = Microsoft.Maui.Controls.Application.Current?.Windows[0]?.Handler?.PlatformView as Microsoft.UI.Xaml.Window;
			if (window == null) return;

			var hwnd = WindowNative.GetWindowHandle(window);

			// Restore if minimized
			ShowWindow(hwnd, SW_RESTORE);

			// Bring to foreground
			SetForegroundWindow(hwnd);
		}

		private static void MaximizeWindow()
		{
			var window = Microsoft.Maui.Controls.Application.Current?.Windows[0]?.Handler?.PlatformView as Microsoft.UI.Xaml.Window;
			if (window == null) return;

			var hwnd = WindowNative.GetWindowHandle(window);
			var windowId = Win32Interop.GetWindowIdFromWindow(hwnd);
			var appWindow = AppWindow.GetFromWindowId(windowId);

			if (appWindow.Presenter is OverlappedPresenter presenter)
			{
				presenter.Maximize();
			}
		}
	}
}
