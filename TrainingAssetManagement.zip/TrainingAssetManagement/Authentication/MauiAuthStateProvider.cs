using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;
using TrainingAssetManagement.Services;
using Microsoft.AspNetCore.Components;

namespace TrainingAssetManagement.Authentication
{
    public class MauiAuthStateProvider : AuthenticationStateProvider
    {
        private readonly AuthService _authService;
        private readonly UserService _userService;
        private readonly RoleService _roleService;
        private readonly NavigationManager _nav;
        private ClaimsPrincipal _currentUser = new ClaimsPrincipal(new ClaimsIdentity());
        public MauiAuthStateProvider(AuthService authService, UserService userService, RoleService roleService, NavigationManager nav)
        {
            _authService = authService;
            _userService = userService;
            _roleService = roleService;
            _nav = nav;
        }
        public async override Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var token = await SecureStorage.GetAsync("auth_token");

            if (string.IsNullOrWhiteSpace(token))
            {
                // User logged out → return anonymous
                return new AuthenticationState(
                    new ClaimsPrincipal(new ClaimsIdentity())
                );
            }

            // User logged in → rebuild ClaimsPrincipal
            var identity = new ClaimsIdentity(JwtParser.ParseClaimsFromJwt(token), "jwt");
            return new AuthenticationState(new ClaimsPrincipal(identity));
        }
        public async Task<AuthenticationState> LogInAsync()
        {
            var result = await _authService.LoginAsync();

            if (result == null)
                return new AuthenticationState(_currentUser);

            var email = result.Account.Username;
            await SecureStorage.SetAsync("auth_token", result.IdToken);

            // Get user record from your database
            var dbUser = await _userService.GetUserByEmail(email);

            if (dbUser == null)
            {
                // No user found → treat as unauthorized
                _currentUser = new ClaimsPrincipal(new ClaimsIdentity());
            }
            else
            {
                var roles = await _roleService.GetRolesAsync();
                var roleName = roles
                    .FirstOrDefault(r => r.RoleID == dbUser.RoleID)
                    ?.Role ?? "User";

                var identity = new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, dbUser.UserName),
                    new Claim(ClaimTypes.Email, dbUser.MailID),
                    new Claim(ClaimTypes.Role, roleName),
                    new Claim("EmployeeID", dbUser.EmployeeID)
                }, authenticationType: "MSAL");

                _currentUser = new ClaimsPrincipal(identity);
            }

            var authState = new AuthenticationState(_currentUser);
            NotifyAuthenticationStateChanged(Task.FromResult(authState));

            return authState;
        }
        public async Task Logout()
        {
            // Log out from Microsoft (MSAL)
            await _authService.LogoutAsync();

            // Remove your own token
            SecureStorage.Remove("auth_token");
            await SecureStorage.SetAsync("logged_out", "true");

            // Reset authentication state
            _currentUser = new ClaimsPrincipal(new ClaimsIdentity());
            NotifyAuthenticationStateChanged(Task.FromResult(new AuthenticationState(_currentUser)));

            // Navigate back to login page
            _nav.NavigateTo("/login", true);
        }
    }
}