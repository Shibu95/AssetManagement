using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Text.Json;

public static class JwtParser
{
    public static IEnumerable<Claim> ParseClaimsFromJwt(string jwt)
    {
        var claims = new List<Claim>();

        if (string.IsNullOrWhiteSpace(jwt))
            return claims;

        // Split JWT (header.payload.signature)
        var payload = jwt.Split('.')[1];

        var jsonBytes = ParseBase64WithoutPadding(payload);
        var keyValuePairs = JsonSerializer.Deserialize<Dictionary<string, object>>(jsonBytes);

        foreach (var kvp in keyValuePairs)
        {
            // Map common JWT claim keys to framework claim types so
            // Identity.Name and ClaimTypes.Email work as expected.
            string claimType = kvp.Key switch
            {
                "name" => ClaimTypes.Name,
                "preferred_username" => ClaimTypes.Name,
                "upn" => ClaimTypes.Name,
                "email" => ClaimTypes.Email,
                "emails" => ClaimTypes.Email,
                _ => kvp.Key
            };

            if (kvp.Value is JsonElement element)
            {
                if (element.ValueKind == JsonValueKind.Array)
                {
                    foreach (var val in element.EnumerateArray())
                    {
                        claims.Add(new Claim(claimType, val.ToString()));
                    }
                }
                else
                {
                    claims.Add(new Claim(claimType, kvp.Value.ToString()));
                }
            }
            else
            {
                claims.Add(new Claim(claimType, kvp.Value?.ToString() ?? string.Empty));
            }
        }

        return claims;
    }

    private static byte[] ParseBase64WithoutPadding(string base64)
    {
        base64 = base64.Replace('-', '+').Replace('_', '/');

        switch (base64.Length % 4)
        {
            case 2: base64 += "=="; break;
            case 3: base64 += "="; break;
        }

        return Convert.FromBase64String(base64);
    }
}