﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Syncfusion.Blazor;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Services;
using TrainingAssetManagement.Authentication;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace TrainingAssetManagement;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("");

		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
			});

		var env = EnvLoader.Load();
		var connectionString = env["PG_CONNECTION"];

		builder.Services.AddDbContext<AppDbContext>(options =>
		{
			options.UseNpgsql(connectionString);
		}, ServiceLifetime.Transient);

		builder.Services.AddScoped<MauiAuthStateProvider>();
		builder.Services.AddScoped<AuthenticationStateProvider>(provider => provider.GetRequiredService<MauiAuthStateProvider>());
		builder.Services.AddSingleton<AuthService>();
		builder.Services.AddScoped<UserService>();
		builder.Services.AddScoped<AuditStatusService>();
		builder.Services.AddScoped<RoleService>();
		builder.Services.AddScoped<TeamsService>();
		builder.Services.AddScoped<WorkLocationsService>();
		builder.Services.AddScoped<AssetsService>();
		builder.Services.AddScoped<AssetGroupsService>();
		builder.Services.AddScoped<AuditsService>();
		builder.Services.AddScoped<AuditReportsService>();
		builder.Services.AddScoped<BranchesService>();
		builder.Services.AddScoped<FloorsService>();
		builder.Services.AddScoped<WorkingStatusService>();
		builder.Services.AddScoped<AvailabilityStatusService>();
		builder.Services.AddScoped<ServiceTrackingStatusService>();
		builder.Services.AddScoped<ServiceTrackingService>();
		builder.Services.AddSingleton<TitleService>();
		builder.Services.AddScoped<AssetAllocationService>();
		builder.Services.AddScoped<AssetPhotoService>();
		builder.Services.AddScoped<ImagePickerService>();
		builder.Services.AddSyncfusionBlazor();
		builder.Services.AddSingleton<SidebarService>();
		builder.Services.AddMauiBlazorWebView();
		builder.Services.AddAuthorizationCore();

#if DEBUG
		builder.Services.AddBlazorWebViewDeveloperTools();
		builder.Logging.AddDebug();
#endif

		return builder.Build();
	}
}