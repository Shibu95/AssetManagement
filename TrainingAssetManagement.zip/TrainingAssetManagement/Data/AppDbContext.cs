using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Models;
using System.Collections.Generic;
using TrainingAssetManagement.Services;
using System.Text.Json;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.Linq;
using TrainingAssetManagement.Models.Dropdowns;

namespace TrainingAssetManagement.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<Roles> Roles { get; set; }
        public DbSet<Assets> Assets { get; set; }
        public DbSet<Branches> Branches { get; set; }
        public DbSet<Floors> Floors { get; set; }
        public DbSet<Teams> Teams { get; set; }
        public DbSet<WorkLocations> WorkLocations { get; set; }
        public DbSet<WorkingStatus> WorkingStatus { get; set; }
        public DbSet<AvailabilityStatus> AvailabilityStatus { get; set; }
        public DbSet<Audits> Audits { get; set; }
        public DbSet<AuditStatus> AuditStatus { get; set; }
        public DbSet<AssetGroups> AssetGroups { get; set; }
        public DbSet<AuditReports> AuditReports { get; set; }
        public DbSet<AssetChangeHistory> AssetChangeHistories { get; set; }
        public DbSet<ServiceTrackingStatus> ServiceTrackingStatus { get; set; }
        public DbSet<ServiceTracking> ServiceTrackings { get; set; }
        public DbSet<AssetAllocation> AssetAllocations { get; set; }
        public DbSet<AssetPhoto> AssetPhotos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Map Audits.AuditBy (string[]) to Postgres text[] (no conversion required)
            var auditByComparer = new ValueComparer<string[]>(
                (a, b) => a.SequenceEqual(b),
                a => string.Join("|", a ?? Array.Empty<string>()).GetHashCode(),
                a => (a ?? Array.Empty<string>()).ToArray()
            );

            modelBuilder.Entity<Audits>().Property(a => a.AuditBy)
                .HasColumnType("text[]")
                .Metadata.SetValueComparer(auditByComparer);
        }
    }
}