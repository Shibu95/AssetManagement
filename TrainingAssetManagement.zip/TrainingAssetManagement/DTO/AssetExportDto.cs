using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.DTO
{
    public class AssetExportDto
    {
        public string AssetID { get; set; }
        public string ProductName { get; set; }
        public string ModelName { get; set; }
        public string SerialNumber { get; set; }
        public string AssignedTo { get; set; }
        public string AllocationType { get; set; }
        public DateTime? AllocationDate { get; set; }
        public DateTime WEO { get; set; }

        public string AssetGroup { get; set; }
        public string Branch { get; set; }
        public string Floor { get; set; }
        public string Location { get; set; }
        public string WorkingStatus { get; set; }
        public string AvailabilityStatus { get; set; }
        public string InternalAllocation { get; set; }

        public string Specification { get; set; }
        public string Description { get; set; }
        public bool EntryValidity { get; set; }
    }
}