using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("servicetracking", Schema = "public")]
    public class ServiceTracking
    {
        [Key]
        public int ServiceTrackingID { get; set; }
        
        [Required(ErrorMessage = "Asset ID is required")]
        [NotMapped]
        public string AssetID { get; set; } = string.Empty;

        [Required]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Ticket ID is required")]
        [MaxLength(300)]
        public string TicketID { get; set; } = string.Empty;

        [Required(ErrorMessage = "Issue Details is required")]
        public string IssueDetails { get; set; } = string.Empty;

        [Required(ErrorMessage = "Status is required")]
        public int ServiceTrackingStatusID { get; set; }

        [Required(ErrorMessage = "Contact Person is required")]
        [MaxLength(150)]
        public string ContactPerson { get; set; } = string.Empty;

        [Required]
        public DateTime ProvidedDate { get; set; }

        public DateTime ReceivedDate { get; set; } = DateTime.MinValue;

        public string Remarks { get; set; } = string.Empty;

    }
}