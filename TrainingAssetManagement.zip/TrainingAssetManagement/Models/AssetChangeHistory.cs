using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("assetchangehistory", Schema = "public")]
    public class AssetChangeHistory
    {
        [Key]
        public int AssetChangeHistoryID { get; set; }

        [Required]
        public int ProductID { get; set; }

        [Required]
        [Column(TypeName = "jsonb")]
        public string NewAssetSnapshot { get; set; } = string.Empty;

        public string ChangedBy { get; set; } = string.Empty;

        [Column(TypeName = "timestamp with time zone")]
        public DateTime ChangedOn { get; set; } = DateTime.UtcNow;
    }
}