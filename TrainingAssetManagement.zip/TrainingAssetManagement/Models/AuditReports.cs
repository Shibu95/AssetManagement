using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("auditreports", Schema = "public")]
    public class AuditReports
    {
        [Key]
        public int AuditEntryID { get; set; }
        public int AuditID { get; set; }

        [Required]
        public int ProductID { get; set; }
        [Required]
        public string AuditedBy { get; set; } = string.Empty;
        [Column(TypeName = "timestamp with time zone")]
        public DateTime AuditedDate { get; set; }
    }
}