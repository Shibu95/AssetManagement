using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("assets", Schema = "public")]
    public class Assets
    {
        [Key]
        public int ProductID { get; set; }
        [Required(ErrorMessage = "Asset ID is required.")]
        public string AssetID { get; set; } = string.Empty;
        [Required(ErrorMessage = "Product Name is required.")]
        public string ProductName { get; set; } = string.Empty;
        public string ModelName { get; set; } = string.Empty;
        public string AssignedTo { get; set; } = string.Empty;
        public string AllocationType { get; set; } = string.Empty;
        public DateTime AllocationDate { get; set; } = DateTime.UtcNow;
        public string Description { get; set; } = string.Empty;
        public string Specification { get; set; } = string.Empty;
        public string SerialNumber { get; set; } = string.Empty;
        public int TeamID { get; set; }
        public DateTime WEO { get; set; } = DateTime.UtcNow;
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Asset Group is required.")] 
        public int AssetGroupID { get; set; }
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Branch is required.")] 
        public int BranchID { get; set; }
        [Required] 
        [Range(1, int.MaxValue, ErrorMessage = "Floor is required.")]
        public int FloorID { get; set; }
        public string Location { get; set; } = string.Empty;        
        [Required] 
        [Range(1, int.MaxValue, ErrorMessage = "Working Status is required.")]
        public int WorkingStatusID { get; set; }
        [Required] 
        [Range(1, int.MaxValue, ErrorMessage = "Availability Status is required.")]
        public int AvailabilityStatusID { get; set; }
        public bool EntryValidity { get; set; } = true;
    }
}