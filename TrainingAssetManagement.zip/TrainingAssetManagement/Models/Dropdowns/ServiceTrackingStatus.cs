using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models.Dropdowns
{
    [Table("servicetrackingstatus", Schema = "public")]
    public class ServiceTrackingStatus
    {
        [Key]
        public int ServiceTrackingStatusID { get; set; }
        [Required]
        public string ServiceTrackingState { get; set; }
    }
}