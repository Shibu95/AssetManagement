using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("branches", Schema = "public")]
    public class Branches
    {
        [Key]
        public int BranchID { get; set; }
        [Required]
        public string BranchName { get; set; }
        [Required(ErrorMessage = "AssetGroup is required")]
        public int? AssetGroupID { get; set; }
    }
}