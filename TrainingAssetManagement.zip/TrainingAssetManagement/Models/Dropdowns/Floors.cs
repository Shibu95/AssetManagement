using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("floors", Schema = "public")]
    public class Floors
    {
        [Key]
        public int FloorID { get; set; }
        [Required]
        public string FloorName { get; set; }
        [Required(ErrorMessage = "Branch is required")]
        public int? BranchID { get; set; }
    }
}