using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("auditstatus", Schema = "public")]
    public class AuditStatus
    {
        [Key]
        public int AuditStatusID { get; set; }
        [Required]
        public string AuditState { get; set; }
    }
}