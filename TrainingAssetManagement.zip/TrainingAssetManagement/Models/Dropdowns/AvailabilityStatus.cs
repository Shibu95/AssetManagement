using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("availabilitystatus", Schema = "public")]
    public class AvailabilityStatus
    {
        [Key]
        public int AvailabilityStatusID { get; set; }
        [Required]
        public string AvailabilityState { get; set; }
    }
}