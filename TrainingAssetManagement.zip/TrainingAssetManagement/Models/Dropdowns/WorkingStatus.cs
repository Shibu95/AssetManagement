using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("workingstatus", Schema = "public")]
    public class WorkingStatus
    {
        [Key]
        public int WorkingStatusID { get; set; }
        [Required]
        public string AssetWorkingStatus { get; set; }
    }
}