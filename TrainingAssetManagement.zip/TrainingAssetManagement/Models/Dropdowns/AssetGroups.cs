using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("assetgroups", Schema = "public")]
    public class AssetGroups
    {
        [Key]
        public int AssetGroupID { get; set; }
        [Required]
        public string AssetGroup { get; set; }
    }
}