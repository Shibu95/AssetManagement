using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("teams", Schema = "public")]
    public class Teams
    {
        [Key]
        public int TeamID { get; set; }
        [Required]
        public string TeamName { get; set; }
    }
}