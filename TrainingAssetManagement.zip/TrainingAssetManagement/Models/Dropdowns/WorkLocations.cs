using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("worklocations", Schema = "public")]
    public class WorkLocations
    {
        [Key]
        public int WorkLocationID { get; set; }
        [Required]
        public string WorkLocation { get; set; }
    }
}