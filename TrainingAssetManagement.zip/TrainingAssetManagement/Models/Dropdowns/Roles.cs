using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("roles", Schema = "public")]
    public class Roles
    {
        [Key]
        public int RoleID { get; set; }
        [Required]
        public string Role { get; set; }
    }
}