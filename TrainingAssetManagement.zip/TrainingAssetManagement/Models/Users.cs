using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("users", Schema = "public")]
    public class Users
    {
        [Key]
        public int UserID { get; set; }
        [Required]
        public string EmployeeID { get; set; } = string.Empty;

        [Required]
        public string UserName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string MailID { get; set; } = string.Empty;

        [Required]
        public int? TeamID { get; set; }

        [Required]
        public int? WorkLocationID { get; set; }

        [Required]
        public int? RoleID { get; set;}
    }
}