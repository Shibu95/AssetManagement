using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("assetphoto", Schema = "public")]
    public class AssetPhoto
    {
        [Key]
        public int AssetPhotoID { get; set; }

        [Required]
        public int ProductID { get; set; }

        [Required]
        public string AssetPhotos { get; set; }
    }
}