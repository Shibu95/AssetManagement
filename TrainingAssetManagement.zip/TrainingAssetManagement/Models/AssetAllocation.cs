using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("assetallocation", Schema = "public")]
    public class AssetAllocation
    {
        [Key]
        public int AssetAllocationID { get; set; }

        [Required]
        public int ProductID { get; set; }

        [Required]
        public string AssignedTo { get; set; } = string.Empty;

        [Required]
        public DateTime AssignedOn { get; set; }

        public string Purpose { get; set; } = string.Empty;

        [Required]
        public string AssignedBy { get; set; } = string.Empty;

        public string ReceivedBy { get; set; } = string.Empty;

        public DateTime? ReceivedOn { get; set; } = DateTime.SpecifyKind(DateTime.MinValue, DateTimeKind.Utc);

        public string Remarks { get; set; } = string.Empty;
    }
}