using System.Collections.Generic;

namespace TrainingAssetManagement.Models
{
    public class ImportResult
    {
        public int Added { get; set; }
        public List<string> AddedIds { get; set; } = new List<string>();
        public List<string> Duplicates { get; set; } = new List<string>();
        public string Error { get; set; } = string.Empty;
    }
}
