using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TrainingAssetManagement.Models
{
    [Table("audits", Schema = "public")]
    public class Audits
    {
        [Key]
        public int AuditID { get; set; }
        [Required(ErrorMessage = "AuditName is required.")]
        public string AuditName { get; set; } = string.Empty;
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Asset Group is required.")]
        public int AssetGroupID { get; set; }
        public DateTime AuditStartDate { get; set; }
        public DateTime AuditEndDate { get; set; }
        [Required]
        public string[] AuditBy { get; set; } = Array.Empty<string>();
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Audit Status is required.")]
        public int AuditStatusID { get; set; }

    }
}