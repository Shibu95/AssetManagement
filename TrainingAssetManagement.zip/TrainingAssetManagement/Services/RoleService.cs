using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services
{
    public class RoleService
    {
        private readonly AppDbContext _db;

        public RoleService(AppDbContext db)
        {
            _db = db;
        }

        // Get all roles
        public async Task<List<Roles>> GetRolesAsync()
        {
            return await _db.Roles.ToListAsync();
        }

        // Add new role
        public async Task<Roles> AddRoleAsync(string roleName)
        {
            var role = new Roles
            {
                Role = roleName
            };

            _db.Roles.Add(role);
            await _db.SaveChangesAsync();
            return role;
        }

        public async Task<bool> DeleteRoleAsync(int roleId)
        {
            var role = await _db.Roles.FirstOrDefaultAsync(r => r.RoleID == roleId);

            if (role == null)
                return false;

            _db.Roles.Remove(role);
            await _db.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateRoleAsync(Roles role)
        {
            var existing = await _db.Roles.FindAsync(role.RoleID);
            if (existing == null) return false;
            existing.Role = role.Role;
            _db.Roles.Update(existing);
            await _db.SaveChangesAsync();
            return true;
        }

    }
}