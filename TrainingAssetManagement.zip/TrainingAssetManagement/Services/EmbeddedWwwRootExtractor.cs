using System;
using System.Reflection;
namespace TrainingAssetManagement.Services;

public static class EmbeddedWwwRootExtractor
{
    public static string Extract()
    {
        var baseDir = Path.Combine(
            Path.GetTempPath(),
            "TrainingAssetManagement",
            "wwwroot"
        );

        Directory.CreateDirectory(baseDir);

        var assembly = Assembly.GetExecutingAssembly();
        var resources = assembly.GetManifestResourceNames()
                                .Where(r => r.StartsWith("wwwroot."));

        foreach (var resource in resources)
        {
            var relativePath = resource["wwwroot.".Length..]
                .Replace('.', Path.DirectorySeparatorChar);

            var filePath = Path.Combine(baseDir, relativePath);

            Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);

            using var stream = assembly.GetManifestResourceStream(resource)!;
            using var file = File.Create(filePath);
            stream.CopyTo(file);
        }

        return baseDir;
    }
}