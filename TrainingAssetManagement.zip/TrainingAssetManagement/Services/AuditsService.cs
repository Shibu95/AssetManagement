using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class AuditsService
    {
        private readonly AppDbContext _context;

        public AuditsService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Audits>> GetAllAudits()
            => await _context.Audits.OrderByDescending(a => a.AuditID).ToListAsync();

        public async Task<Audits> GetAuditById(int id)
            => await _context.Audits.FirstOrDefaultAsync(a => a.AuditID == id);

        public async Task<int> CreateAudit(Audits audit)
        {
            await _context.Audits.AddAsync(audit);
            await _context.SaveChangesAsync();

            // AuditTags no longer stored per-asset; nothing to update on assets here.
            return audit.AuditID;
        }

        public async Task UpdateAudit(Audits model)
        {
            var existing = await _context.Audits.FindAsync(model.AuditID);
            if (existing == null) return;

            _context.Entry(existing).CurrentValues.SetValues(model);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAuditById(int id)
        {
            var rec = await _context.Audits.FindAsync(id);
            if (rec == null) return;

            _context.Audits.Remove(rec);
            await _context.SaveChangesAsync();
        }
    }
}