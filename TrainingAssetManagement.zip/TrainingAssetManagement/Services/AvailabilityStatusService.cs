using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class AvailabilityStatusService
    {
        private readonly AppDbContext _context;
        public AvailabilityStatusService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<AvailabilityStatus>> GetAllAvailabilityStatus()
        {
            return await _context.AvailabilityStatus.ToListAsync();
        }

        public async Task<AvailabilityStatus> AddAvailabilityStatusAsync(string value)
        {
            var e = new AvailabilityStatus { AvailabilityState = value };
            _context.AvailabilityStatus.Add(e);
            await _context.SaveChangesAsync();
            return e;
        }

        public async Task<bool> UpdateAvailabilityStatusAsync(AvailabilityStatus s)
        {
            var existing = await _context.AvailabilityStatus.FindAsync(s.AvailabilityStatusID);
            if (existing == null) return false;
            existing.AvailabilityState = s.AvailabilityState;
            _context.AvailabilityStatus.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAvailabilityStatusAsync(int id)
        {
            var existing = await _context.AvailabilityStatus.FindAsync(id);
            if (existing == null) return false;
            _context.AvailabilityStatus.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }

    }
}