using System;

namespace TrainingAssetManagement.Services
{
    public class SidebarService
    {
        private bool _isCollapsed = true;
        public bool IsCollapsed => _isCollapsed;

        public event Action? OnChange;

        public void Toggle()
        {
            _isCollapsed = !_isCollapsed;
            OnChange?.Invoke();
        }

        public void Set(bool value)
        {
            if (_isCollapsed == value) return;
            _isCollapsed = value;
            OnChange?.Invoke();
        }
    }
}
