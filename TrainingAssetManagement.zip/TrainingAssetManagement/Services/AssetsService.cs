using System;
using System.Linq;
using System.Reflection;
using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services
{
    public class AssetsService
    {
        private readonly AppDbContext _context;

        public AssetsService(AppDbContext context)
        {
            _context = context;
        }

        private static string GetIstNowString()
        {
            TimeZoneInfo tz = null;
            try { tz = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
            catch
            {
                try { tz = TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); }
                catch { tz = null; }
            }

            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, tz) : DateTime.UtcNow.ToLocalTime();
            return ist.ToString("dd/MM/yyyy hh:mm tt");
        }

        private static TimeZoneInfo? GetIndiaTimeZone()
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
            catch
            {
                try { return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); }
                catch { return null; }
            }
        }

        private static DateTime ToUtcFromIstDateOnly(DateTime dateOnly)
        {
            return DateTime.SpecifyKind(new DateTime(dateOnly.Year, dateOnly.Month, dateOnly.Day, 0, 0, 0), DateTimeKind.Utc);
        }

        private static DateTime GetIstDatePart(DateTime dt)
        {
            var tz = GetIndiaTimeZone();
            DateTime utc = NormalizeToUtc(dt);
            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(utc, tz) : utc.ToLocalTime();
            return ist.Date;
        }

        private static string ToIstDateString(DateTime dt)
        {
            var tz = GetIndiaTimeZone();
            DateTime utc = NormalizeToUtc(dt);
            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(utc, tz) : utc.ToLocalTime();
            return ist.ToString("dd/MM/yyyy");
        }

        private static string ToIstDateTimeString(DateTime dt)
        {
            var tz = GetIndiaTimeZone();
            DateTime utc = NormalizeToUtc(dt);
            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(utc, tz) : utc.ToLocalTime();
            return ist.ToString("dd/MM/yyyy hh:mm tt");
        }

        private static string SerializeSnapshotWithFormatting(object obj)
        {
            try
            {
                var dict = new Dictionary<string, object?>(StringComparer.OrdinalIgnoreCase);
                var props = obj.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance);
                foreach (var p in props)
                {
                    var name = p.Name;
                    object? val = p.GetValue(obj);
                    if (val is DateTime dt)
                    {
                        if (string.Equals(name, "AllocationDate", StringComparison.OrdinalIgnoreCase) ||
                                string.Equals(name, "WEO", StringComparison.OrdinalIgnoreCase))
                        {
                            dict[name] = ToIstDateString(dt);
                        }
                        else
                        {
                            dict[name] = dt.ToString("o");
                        }
                    }
                    else
                    {
                        dict[name] = val;
                    }
                }
                var options = new JsonSerializerOptions { WriteIndented = false };
                return JsonSerializer.Serialize(dict, options);
            }
            catch
            {
                // fallback to default serialization
                return JsonSerializer.Serialize(obj);
            }
        }

        private static string FormatToIst(DateTime utcOrLocal)
        {
            TimeZoneInfo tz = null;
            try { tz = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
            catch
            {
                try { tz = TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); }
                catch { tz = null; }
            }
            DateTime utc;
            if (utcOrLocal.Kind == DateTimeKind.Utc)
            {
                utc = utcOrLocal;
            }
            else if (utcOrLocal.Kind == DateTimeKind.Local)
            {
                utc = utcOrLocal.ToUniversalTime();
            }
            else // Unspecified - assume stored as UTC
            {
                utc = DateTime.SpecifyKind(utcOrLocal, DateTimeKind.Utc);
            }

            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(utc, tz) : utc.ToLocalTime();
            return ist.ToString("dd/MM/yyyy hh:mm tt");
        }

        private static string FormatDateToIst(DateTime utcOrLocal)
        {
            TimeZoneInfo tz = null;
            try { tz = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
            catch
            {
                try { tz = TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); }
                catch { tz = null; }
            }
            DateTime utc;
            if (utcOrLocal.Kind == DateTimeKind.Utc)
            {
                utc = utcOrLocal;
            }
            else if (utcOrLocal.Kind == DateTimeKind.Local)
            {
                utc = utcOrLocal.ToUniversalTime();
            }
            else // Unspecified - assume stored as UTC
            {
                utc = DateTime.SpecifyKind(utcOrLocal, DateTimeKind.Utc);
            }

            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(utc, tz) : utc.ToLocalTime();
            return ist.ToString("dd/MM/yyyy");
        }

        private static DateTime NormalizeToUtc(DateTime dt)
        {
            if (dt.Kind == DateTimeKind.Utc) return dt;
            if (dt.Kind == DateTimeKind.Local) return DateTime.SpecifyKind(dt.ToUniversalTime(), DateTimeKind.Utc);
            return DateTime.SpecifyKind(dt, DateTimeKind.Utc);
        }

        public async Task<List<Assets>> GetAllAssets()
        {
            return await _context.Assets.ToListAsync();
        }

        public async Task<Assets> GetAssetByAssetId(string assetId)
        {
            return await _context.Assets.FirstOrDefaultAsync(a => a.AssetID == assetId);
        }

        public async Task AddAsset(Assets asset, string? userName = null)
        {
            // Ensure WEO and AllocationDate are interpreted as date-only in IST and stored as UTC
            asset.WEO = ToUtcFromIstDateOnly(asset.WEO.Date);
            asset.AllocationDate = ToUtcFromIstDateOnly(asset.AllocationDate.Date);

            _context.Assets.Add(asset);
            try
            {
                await _context.SaveChangesAsync();
                if (!string.IsNullOrEmpty(userName))
                {
                    var entry = new AssetChangeHistory
                    {
                        ProductID = asset.ProductID,
                        NewAssetSnapshot = SerializeSnapshotWithFormatting(asset),
                        ChangedBy = userName,
                        ChangedOn = DateTimeUtils.UtcNowFromIst()
                    };
                    _context.AssetChangeHistories.Add(entry);
                    await _context.SaveChangesAsync();
                }
            }
            catch (DbUpdateException dbEx)
            {
                var inner = dbEx.InnerException?.Message ?? dbEx.Message;
                throw new Exception($"Failed saving asset: {inner}", dbEx);
            }
        }
        public async Task<Assets?> GetAssetByProductId(int productId)
        {
            return await _context.Assets
                .FirstOrDefaultAsync(a => a.ProductID == productId);
        }

        public async Task UpdateAsset(Assets asset, string? userName = null)
        {
            var existing = await _context.Assets
                    .FirstOrDefaultAsync(a => a.ProductID == asset.ProductID);

            if (existing != null)
            {
                var changes = new List<string>();
                var istNow = GetIstNowString();

                string user = string.IsNullOrEmpty(userName) ? "System" : userName;

                void AddChangeStr(string field, string oldStr, string newStr)
                {
                    if (oldStr != newStr)
                    {
                        changes.Add($"{user} changed {field} from '{oldStr}' to '{newStr}' at {istNow}");
                    }
                }

                AddChangeStr("ProductName", existing.ProductName ?? string.Empty, asset.ProductName ?? string.Empty);
                AddChangeStr("ModelName", existing.ModelName ?? string.Empty, asset.ModelName ?? string.Empty);
                AddChangeStr("AssignedTo", existing.AssignedTo ?? string.Empty, asset.AssignedTo ?? string.Empty);
                AddChangeStr("AllocationType", existing.AllocationType ?? string.Empty, asset.AllocationType ?? string.Empty);


                // AllocationDate (non-nullable): compare by IST date only
                var oldIstDate = GetIstDatePart(existing.AllocationDate);
                var newIstDate = GetIstDatePart(asset.AllocationDate);

                if (oldIstDate != newIstDate)
                {
                    AddChangeStr(
                        "AllocationDate",
                        oldIstDate.ToString("dd/MM/yyyy"),
                        newIstDate.ToString("dd/MM/yyyy")
                    );
                }
                // normalize incoming allocation date (IST date-only → UTC)
                asset.AllocationDate = ToUtcFromIstDateOnly(asset.AllocationDate.Date);

                AddChangeStr("Description", existing.Description ?? string.Empty, asset.Description ?? string.Empty);
                AddChangeStr("Specification", existing.Specification ?? string.Empty, asset.Specification ?? string.Empty);
                AddChangeStr("SerialNumber", existing.SerialNumber ?? string.Empty, asset.SerialNumber ?? string.Empty);
                // AddChangeStr("BranchName", existing.BranchName ?? string.Empty, asset.BranchName ?? string.Empty);
                // AddChangeStr("FloorName", existing.FloorName ?? string.Empty, asset.FloorName ?? string.Empty);
                // AddChangeStr("WorkingStatus", existing.WorkingStatus ?? string.Empty, asset.WorkingStatus ?? string.Empty);
                // AddChangeStr("AvailabilityStatus", existing.AvailabilityStatus ?? string.Empty, asset.AvailabilityStatus ?? string.Empty);
                if (existing.BranchID != asset.BranchID)
                    AddChangeStr("Branch", existing.BranchID.ToString(), asset.BranchID.ToString());

                if (existing.FloorID != asset.FloorID)
                    AddChangeStr("Floor", existing.FloorID.ToString(), asset.FloorID.ToString());

                if (existing.WorkingStatusID != asset.WorkingStatusID)
                    AddChangeStr("Working Status",
                        existing.WorkingStatusID.ToString(),
                        asset.WorkingStatusID.ToString());

                if (existing.AvailabilityStatusID != asset.AvailabilityStatusID)
                    AddChangeStr("Availability",
                        existing.AvailabilityStatusID.ToString(),
                        asset.AvailabilityStatusID.ToString());


                // Special handling for WEO: treat as date-only (dd/MM/yyyy) to avoid timezone shifts
                // compare WEO by IST date to avoid timezone shifts
                var oldWEOIst = GetIstDatePart(existing.WEO);
                var newWEOIst = GetIstDatePart(asset.WEO);
                if (oldWEOIst != newWEOIst)
                {
                    var oldFmt = oldWEOIst.ToString("dd/MM/yyyy");
                    var newFmt = newWEOIst.ToString("dd/MM/yyyy");
                    AddChangeStr("WEO", oldFmt, newFmt);
                }

                // normalize incoming asset.WEO: interpret as IST date-only and store as UTC
                asset.WEO = ToUtcFromIstDateOnly(asset.WEO.Date);

                if (changes.Count > 0)
                {
                    // capture old snapshot BEFORE applying incoming values
                    var oldJson = SerializeSnapshotWithFormatting(existing);

                    // ModifiedDate property removed; no timestamp set here
                    // apply incoming values
                    _context.Entry(existing).CurrentValues.SetValues(asset);

                    // persist changes, then capture new snapshot
                    await _context.SaveChangesAsync();
                    var actor = string.IsNullOrEmpty(userName) ? "System" : userName;
                    var newJson = SerializeSnapshotWithFormatting(existing);
                    var entry = new AssetChangeHistory
                    {
                        ProductID = existing.ProductID,
                        NewAssetSnapshot = newJson,
                        ChangedBy = actor,
                        ChangedOn = DateTimeUtils.UtcNowFromIst()
                    };
                    _context.AssetChangeHistories.Add(entry);
                    await _context.SaveChangesAsync();
                }
                else
                {
                    // no field-level changes, still update the entity (if any normalization applied)
                    _context.Entry(existing).CurrentValues.SetValues(asset);
                    await _context.SaveChangesAsync();
                }
            }

        }

        public async Task<List<AssetChangeHistory>> GetChangeHistoryByAssetId(int productId)
        {
            return await _context.AssetChangeHistories
                .Where(h => h.ProductID == productId)
                .OrderByDescending(h => h.ChangedOn)
                .ToListAsync();
        }

        public async Task AppendHistoryEntry(int productId, string note, string? userName = null)
        {
            var actor = string.IsNullOrEmpty(userName) ? "System" : userName;
            var noteJson = System.Text.Json.JsonSerializer.Serialize(new { note = note ?? string.Empty });
            var entry = new AssetChangeHistory
            {
                ProductID = productId,
                NewAssetSnapshot = noteJson,
                ChangedBy = actor,
                ChangedOn = DateTimeUtils.UtcNowFromIst()
            };
            _context.AssetChangeHistories.Add(entry);
            await _context.SaveChangesAsync();
        }
        public async Task UpdateAssetAvailabilityByState(int productId, string availabilityState)
        {
            var availability = await _context.AvailabilityStatus
                .FirstOrDefaultAsync(a =>
                    a.AvailabilityState == availabilityState);

            if (availability == null)
                throw new InvalidOperationException(
                    $"AvailabilityStatus '{availabilityState}' not found.");

            var asset = await _context.Assets
                .FirstOrDefaultAsync(a => a.ProductID == productId);

            if (asset == null)
                throw new InvalidOperationException("Asset not found.");

            asset.AvailabilityStatusID = availability.AvailabilityStatusID;

            await _context.SaveChangesAsync();
        }

        public async Task DeleteAssetByAssetID(string assetId)
        {
            var asset = await _context.Assets
                .FirstOrDefaultAsync(a => a.AssetID == assetId);

            if (asset == null)
                return;

            int productId = asset.ProductID;

            using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                await _context.Database.ExecuteSqlRawAsync(
                    "DELETE FROM public.auditreports WHERE \"ProductID\" = {0}", productId);

                await _context.Database.ExecuteSqlRawAsync(
                    "DELETE FROM public.assetallocation WHERE \"ProductID\" = {0}", productId);

                await _context.Database.ExecuteSqlRawAsync(
                    "DELETE FROM public.servicetracking WHERE \"ProductID\" = {0}", productId);

                await _context.Database.ExecuteSqlRawAsync(
                    "DELETE FROM public.assetphoto WHERE \"ProductID\" = {0}", productId);

                await _context.Database.ExecuteSqlRawAsync(
                    "DELETE FROM public.assetchangehistory WHERE \"ProductID\" = {0}", productId);

                _context.Assets.Remove(asset);
                await _context.SaveChangesAsync();

                await tx.CommitAsync();
            }
            catch (Exception ex)
            {
                await tx.RollbackAsync();
                throw new Exception("Failed deleting asset: " + ex.Message, ex);
            }
        }

        public async Task<ImportResult> BulkImportAssets(List<Assets> assets, string? userName = null)
        {
            var duplicates = new List<string>();
            var toAdd = new List<Assets>();

            foreach (var a in assets)
            {
                var exists = await _context.Assets.AnyAsync(x => x.AssetID == a.AssetID);
                if (exists)
                {
                    duplicates.Add(a.AssetID);
                }
                else
                {
                    // a change snapshot will be created after save
                    toAdd.Add(a);
                }
            }

            var result = new ImportResult { Added = 0, Duplicates = duplicates ?? new List<string>(), AddedIds = new List<string>(), Error = string.Empty };

            if (toAdd.Count > 0)
            {
                try
                {
                    // normalize date fields for imported assets to date-only UTC
                    foreach (var added in toAdd)
                    {
                        added.AllocationDate = ToUtcFromIstDateOnly(added.AllocationDate.Date);
                        added.WEO = ToUtcFromIstDateOnly(added.WEO.Date);
                    }
                    await _context.AddRangeAsync(toAdd);
                    await _context.SaveChangesAsync();
                    // create change history entries for added assets
                    if (!string.IsNullOrEmpty(userName))
                    {
                        foreach (var added in toAdd)
                        {
                            var entry = new AssetChangeHistory
                            {
                                ProductID = added.ProductID,
                                NewAssetSnapshot = SerializeSnapshotWithFormatting(added),
                                ChangedBy = userName,
                                ChangedOn = DateTimeUtils.UtcNowFromIst()
                            };
                            _context.AssetChangeHistories.Add(entry);
                        }
                        await _context.SaveChangesAsync();
                    }

                    result.Added = toAdd.Count;
                    result.AddedIds = toAdd.Select(x => x.AssetID).ToList();
                    return result;
                }
                catch (Microsoft.EntityFrameworkCore.DbUpdateException dbEx)
                {
                    // return DB error message to caller for user-friendly display
                    var inner = dbEx.InnerException?.Message ?? dbEx.Message;
                    result.Error = inner;
                    return result;
                }
                catch (Exception ex)
                {
                    result.Error = ex.Message;
                    return result;
                }
            }

            return result;
        }
    }
}