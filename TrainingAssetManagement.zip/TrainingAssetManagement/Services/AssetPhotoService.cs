using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services
{
    public class AssetPhotoService
    {

        private readonly AppDbContext _context;

        public AssetPhotoService(AppDbContext context)
        {
            _context = context;
        }


        public async Task AddPhotosAsync(int productId, List<byte[]> photos)
        {
            if (photos == null || photos.Count == 0) return;

            var entities = photos.Select(p => new AssetPhoto
            {
                ProductID = productId,
                AssetPhotos = $"data:image/png;base64,{Convert.ToBase64String(p)}"
            });

            _context.AssetPhotos.AddRange(entities);
            await _context.SaveChangesAsync();
        }

        public async Task<List<AssetPhoto>> GetPhotosByProductIdAsync(int productId)
        {
            return await _context.AssetPhotos
                .Where(x => x.ProductID == productId)
                .OrderByDescending(x => x.AssetPhotoID)
                .ToListAsync();
        }

        public async Task DeletePhotoAsync(int assetPhotoId)
        {
            var photo = await _context.AssetPhotos.FindAsync(assetPhotoId);
            if (photo != null)
            {
                _context.AssetPhotos.Remove(photo);
                await _context.SaveChangesAsync();
            }
        }

    }
}