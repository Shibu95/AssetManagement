using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models.Dropdowns;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class ServiceTrackingStatusService
    {

        private readonly AppDbContext _context;

        public ServiceTrackingStatusService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<ServiceTrackingStatus>> GetAllServiceTrackingStatus()
        {
            return await _context.ServiceTrackingStatus.ToListAsync();
        }

        public async Task<ServiceTrackingStatus> AddServiceTrackingStatusAsync(string value)
        {
            var e = new ServiceTrackingStatus { ServiceTrackingState = value };
            _context.ServiceTrackingStatus.Add(e);
            await _context.SaveChangesAsync();
            return e;
        }

        public async Task<bool> UpdateServiceTrackingStatusAsync(ServiceTrackingStatus ws)
        {
            var existing = await _context.ServiceTrackingStatus.FindAsync(ws.ServiceTrackingStatusID);
            if (existing == null) return false;
            existing.ServiceTrackingState = ws.ServiceTrackingState;
            _context.ServiceTrackingStatus.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteWorkingStatusAsync(int id)
        {
            var existing = await _context.ServiceTrackingStatus.FindAsync(id);
            if (existing == null) return false;
            _context.ServiceTrackingStatus.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }

    }
}