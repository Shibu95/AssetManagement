using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services
{
    public class ServiceTrackingService
    {
        private readonly AppDbContext _context;

        private const string STATUS_IN_SERVICE = "In-service";
        private const string STATUS_RECEIVED = "Received";

        private const string AVAILABILITY_IN_USE = "In-Service";
        private const string AVAILABILITY_NOT_IN_USE = "Not-In-Use";

        public ServiceTrackingService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<ServiceTracking>> GetAllServiceTrackings()
        {
            return await _context.ServiceTrackings
                .OrderByDescending(s => s.ServiceTrackingID)
                .ToListAsync();
        }

        public async Task<ServiceTracking?> GetServiceTrackingByTrackingId(int id)
            => await _context.ServiceTrackings.FindAsync(id);

        public async Task<int> CreateServiceTracking(ServiceTracking model)
        {
            // Resolve "In-service" status
            var status = await _context.ServiceTrackingStatus
                .FirstOrDefaultAsync(s => s.ServiceTrackingState == STATUS_IN_SERVICE);

            if (status == null)
                throw new InvalidOperationException("ServiceTrackingStatus 'In-service' not found.");

            model.ServiceTrackingStatusID = status.ServiceTrackingStatusID;

            model.ReceivedDate = DateTime.MinValue;

            await _context.ServiceTrackings.AddAsync(model);

            await UpdateAssetAvailabilityAsync(
                model.ProductID,
                STATUS_IN_SERVICE
            );

            await _context.SaveChangesAsync();
            return model.ServiceTrackingID;
        }

        public async Task UpdateServiceTracking(ServiceTracking model)
        {
            var existing = await _context.ServiceTrackings
                .AsTracking()
                .FirstOrDefaultAsync(s => s.ServiceTrackingID == model.ServiceTrackingID);

            if (existing == null) return;

            // Resolve previous status value
            var previousStatusValue = await _context.ServiceTrackingStatus
                .Where(s => s.ServiceTrackingStatusID == existing.ServiceTrackingStatusID)
                .Select(s => s.ServiceTrackingState)
                .FirstOrDefaultAsync();

            _context.Entry(existing).CurrentValues.SetValues(model);

            // Resolve new status value
            var currentStatusValue = await _context.ServiceTrackingStatus
                .Where(s => s.ServiceTrackingStatusID == model.ServiceTrackingStatusID)
                .Select(s => s.ServiceTrackingState)
                .FirstOrDefaultAsync();

            // Apply ReceivedDate ONLY when status becomes "Received"
            if (currentStatusValue == STATUS_RECEIVED &&
                previousStatusValue != STATUS_RECEIVED)
            {
                existing.ReceivedDate = DateTime.UtcNow;
            }

            await UpdateAssetAvailabilityAsync(
                existing.ProductID,
                currentStatusValue
            );

            await _context.SaveChangesAsync();
        }

        public async Task DeleteServiceTrackingById(int id)
        {
            var rec = await _context.ServiceTrackings.FindAsync(id);
            if (rec == null) return;

            _context.ServiceTrackings.Remove(rec);
            await _context.SaveChangesAsync();
        }

        private async Task UpdateAssetAvailabilityAsync(int productId, string serviceTrackingStatusValue)
        {
            var asset = await _context.Assets
                .AsTracking()
                .FirstOrDefaultAsync(a => a.ProductID == productId);

            if (asset == null) return;

            string availabilityValue =
                serviceTrackingStatusValue == STATUS_IN_SERVICE
                    ? AVAILABILITY_IN_USE
                    : serviceTrackingStatusValue == STATUS_RECEIVED
                        ? AVAILABILITY_NOT_IN_USE
                        : string.Empty;

            if (string.IsNullOrEmpty(availabilityValue)) return;

            var availabilityStatus = await _context.AvailabilityStatus
                .FirstOrDefaultAsync(a => a.AvailabilityState == availabilityValue);

            if (availabilityStatus == null)
                throw new InvalidOperationException(
                    $"AvailabilityStatus '{availabilityValue}' not found.");

            asset.AvailabilityStatusID = availabilityStatus.AvailabilityStatusID;
        }
    }
}