using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services;

public class WorkLocationsService
{
    private readonly AppDbContext _db;

    public WorkLocationsService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<WorkLocations>> GetAllWorkLocations()
    {
        return await _db.Set<WorkLocations>().ToListAsync();
    }

    public async Task<WorkLocations> AddWorkLocationAsync(string name)
    {
        var e = new WorkLocations { WorkLocation = name };
        _db.WorkLocations.Add(e);
        await _db.SaveChangesAsync();
        return e;
    }

    public async Task<bool> UpdateWorkLocationAsync(WorkLocations wl)
    {
        var existing = await _db.WorkLocations.FindAsync(wl.WorkLocationID);
        if (existing == null) return false;
        existing.WorkLocation = wl.WorkLocation;
        _db.WorkLocations.Update(existing);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteWorkLocationAsync(int id)
    {
        var existing = await _db.WorkLocations.FindAsync(id);
        if (existing == null) return false;
        _db.WorkLocations.Remove(existing);
        await _db.SaveChangesAsync();
        return true;
    }
}
