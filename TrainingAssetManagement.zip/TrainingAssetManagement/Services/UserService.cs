using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services;

public class UserService
{
    private readonly AppDbContext _db;

    public UserService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<Users> GetUserByEmail(string email)
    {
        return await _db.Users.FirstOrDefaultAsync(u => u.MailID == email);
    }

    public async Task<List<Users>> GetAllUsers()
    {
        return await _db.Users.ToListAsync();
    }

    public async Task<Users> GetUserById(int id)
    {
        return await _db.Users.FirstOrDefaultAsync(u => u.UserID == id);
    }

    public async Task<Users> GetUserByEmployeeID(string employeeId)
    {
        return await _db.Users.FirstOrDefaultAsync(u => u.EmployeeID == employeeId);
    }

    public async Task AddUser(Users user)
    {
        _db.Users.Add(user);
        await _db.SaveChangesAsync();
    }

    public async Task UpdateUser(Users user)
    {
        _db.Users.Update(user);
        await _db.SaveChangesAsync();
    }

    public async Task DeleteUserById(int id)
    {
        var u = await _db.Users.FirstOrDefaultAsync(x => x.UserID == id);
        if (u != null)
        {
            _db.Users.Remove(u);
            await _db.SaveChangesAsync();
        }
    }

}