using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services
{
    public class ImagePickerService
    {
        public async Task<List<byte[]>> PickImagesAsync()
        {
            var files = await FilePicker.PickMultipleAsync(new PickOptions
            {
                PickerTitle = "Select Asset Photos",
                FileTypes = FilePickerFileType.Images
            });

            var result = new List<byte[]>();

            foreach (var file in files)
            {
                using var stream = await file.OpenReadAsync();
                using var ms = new MemoryStream();
                await stream.CopyToAsync(ms);
                result.Add(ms.ToArray());
            }

            return result;
        }

    }
}