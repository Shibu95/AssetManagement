using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class FloorsService
    {
        private readonly AppDbContext _context;
        public FloorsService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Floors>> GetAllFloors()
        {
            return await _context.Floors.ToListAsync();
        }

        public async Task<List<Floors>> GetFloorByBranchID(int branchId)
        {
            return await _context.Floors.Where(x => x.BranchID == branchId).ToListAsync();
        }

        public async Task<Floors> AddFloorAsync(Floors floor)
        {
            _context.Floors.Add(floor);
            await _context.SaveChangesAsync();
            return floor;
        }

        public async Task<bool> UpdateFloorAsync(Floors floor)
        {
            var existing = await _context.Floors.FindAsync(floor.FloorID);
            if (existing == null) return false;
            existing.FloorName = floor.FloorName;
            existing.BranchID = floor.BranchID;
            _context.Floors.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteFloorAsync(int floorId)
        {
            var existing = await _context.Floors.FindAsync(floorId);
            if (existing == null) return false;
            _context.Floors.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}