using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class AuditStatusService
    {
        private readonly AppDbContext _context;

        public AuditStatusService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<AuditStatus>> GetAllAuditStatuses()
        {
            return await _context.Set<AuditStatus>().ToListAsync();
        }

        public async Task<AuditStatus> AddAuditStatusAsync(string value)
        {
            var e = new AuditStatus { AuditState = value };
            _context.AuditStatus.Add(e);
            await _context.SaveChangesAsync();
            return e;
        }

        public async Task<bool> UpdateAuditStatusAsync(AuditStatus s)
        {
            var existing = await _context.AuditStatus.FindAsync(s.AuditStatusID);
            if (existing == null) return false;
            existing.AuditState = s.AuditState;
            _context.AuditStatus.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteAuditStatusAsync(int id)
        {
            var existing = await _context.AuditStatus.FindAsync(id);
            if (existing == null) return false;
            _context.AuditStatus.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
