using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services;

public class AssetGroupsService
{
    private readonly AppDbContext _db;

    public AssetGroupsService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<AssetGroups>> GetAllAssetGroups()
    {
        return await _db.Set<AssetGroups>().ToListAsync();
    }

    public async Task<AssetGroups> AddAssetGroupAsync(string name)
    {
        var entity = new AssetGroups { AssetGroup = name };
        _db.AssetGroups.Add(entity);
        await _db.SaveChangesAsync();
        return entity;
    }

    public async Task<bool> UpdateAssetGroupAsync(AssetGroups group)
    {
        var existing = await _db.AssetGroups.FindAsync(group.AssetGroupID);
        if (existing == null) return false;
        existing.AssetGroup = group.AssetGroup;
        _db.AssetGroups.Update(existing);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteAssetGroupAsync(int id)
    {
        var existing = await _db.AssetGroups.FindAsync(id);
        if (existing == null) return false;
        _db.AssetGroups.Remove(existing);
        await _db.SaveChangesAsync();
        return true;
    }
}
