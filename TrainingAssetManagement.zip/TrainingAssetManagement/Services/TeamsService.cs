using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services;

public class TeamsService
{
    private readonly AppDbContext _db;

    public TeamsService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<List<Teams>> GetAllTeams()
    {
        return await _db.Set<Teams>().ToListAsync();
    }

    public async Task<Teams> AddTeamAsync(string name)
    {
        var t = new Teams { TeamName = name };
        _db.Teams.Add(t);
        await _db.SaveChangesAsync();
        return t;
    }

    public async Task<bool> UpdateTeamAsync(Teams team)
    {
        var existing = await _db.Teams.FindAsync(team.TeamID);
        if (existing == null) return false;
        existing.TeamName = team.TeamName;
        _db.Teams.Update(existing);
        await _db.SaveChangesAsync();
        return true;
    }

    public async Task<bool> DeleteTeamAsync(int id)
    {
        var existing = await _db.Teams.FindAsync(id);
        if (existing == null) return false;
        _db.Teams.Remove(existing);
        await _db.SaveChangesAsync();
        return true;
    }
}
