using System;

namespace TrainingAssetManagement.Services
{
    public static class DateTimeUtils
    {
        public static TimeZoneInfo? GetIndiaTimeZone()
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById("India Standard Time"); }
            catch
            {
                try { return TimeZoneInfo.FindSystemTimeZoneById("Asia/Kolkata"); }
                catch { return null; }
            }
        }

        // Return a UTC DateTime that represents the current time in IST.
        public static DateTime UtcNowFromIst()
        {
            var tz = GetIndiaTimeZone();
            // current instant in UTC
            var utcNow = DateTime.UtcNow;
            if (tz == null) return DateTime.SpecifyKind(utcNow, DateTimeKind.Utc);
            // Convert UTC -> IST local time, then convert that IST-local time back to UTC
            var istNow = TimeZoneInfo.ConvertTimeFromUtc(utcNow, tz);
            var utcFromIst = TimeZoneInfo.ConvertTimeToUtc(istNow, tz);
            return DateTime.SpecifyKind(utcFromIst, DateTimeKind.Utc);
        }

        public static string GetIstNowString()
        {
            var tz = GetIndiaTimeZone();
            var utcNow = DateTime.UtcNow;
            var ist = tz != null ? TimeZoneInfo.ConvertTimeFromUtc(utcNow, tz) : utcNow.ToLocalTime();
            return ist.ToString("dd/MM/yyyy hh:mm tt");
        }

        public static string ToIstString(DateTime dt)
        {
            var tz = GetIndiaTimeZone();

            DateTime utc;
            if (dt.Kind == DateTimeKind.Utc)
            {
                utc = dt;
            }
            else if (dt.Kind == DateTimeKind.Local)
            {
                utc = dt.ToUniversalTime();
            }
            else
            {
                utc = DateTime.SpecifyKind(dt, DateTimeKind.Utc);
            }

            var ist = tz != null
                ? TimeZoneInfo.ConvertTimeFromUtc(utc, tz)
                : utc.ToLocalTime();

            return ist.ToString("dd/MM/yyyy hh:mm tt");
        }
    }
}
