using Microsoft.Identity.Client;

namespace TrainingAssetManagement.Services
{
    public class AuthService
    {
        private readonly IPublicClientApplication _pca;

        private readonly string[] Scopes = { "User.Read" };

        public AuthService()
        {
            _pca = PublicClientApplicationBuilder
                .Create("0062fe7d-770e-4bd6-9bf6-e014d8caa9ab")
                .WithTenantId("77f1fe12-b049-4919-8c50-9fb41e5bb63b")
                .WithRedirectUri("http://localhost")
                .Build();
        }

        public async Task<AuthenticationResult> LoginAsync()
        {
            try
            {
                var accounts = await _pca.GetAccountsAsync();
                return await _pca.AcquireTokenSilent(Scopes, accounts.FirstOrDefault()).ExecuteAsync();
            }
            catch (MsalUiRequiredException)
            {
                return await _pca.AcquireTokenInteractive(Scopes).ExecuteAsync();
            }
        }

        public async Task LogoutAsync()
        {
            try
            {
                var accounts = await _pca.GetAccountsAsync();

                foreach (var account in accounts)
                {
                    await _pca.RemoveAsync(account);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"MSAL logout failed: {ex.Message}");
            }
        }

    }
}