using System;

namespace TrainingAssetManagement.Services
{
    public class TitleService
    {
        private string _title = string.Empty;
        public string CurrentTitle => _title;

        public event Action<string>? TitleChanged;

        public void SetTitle(string title)
        {
            _title = title ?? string.Empty;
            TitleChanged?.Invoke(_title);
        }
    }
}
