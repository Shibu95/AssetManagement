using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class WorkingStatusService
    {

        private readonly AppDbContext _context;
        public WorkingStatusService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<WorkingStatus>> GetAllWorkingStatus()
        {
            return await _context.WorkingStatus.ToListAsync();
        }

        public async Task<WorkingStatus> AddWorkingStatusAsync(string value)
        {
            var e = new WorkingStatus { AssetWorkingStatus = value };
            _context.WorkingStatus.Add(e);
            await _context.SaveChangesAsync();
            return e;
        }

        public async Task<bool> UpdateWorkingStatusAsync(WorkingStatus ws)
        {
            var existing = await _context.WorkingStatus.FindAsync(ws.WorkingStatusID);
            if (existing == null) return false;
            existing.AssetWorkingStatus = ws.AssetWorkingStatus;
            _context.WorkingStatus.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteWorkingStatusAsync(int id)
        {
            var existing = await _context.WorkingStatus.FindAsync(id);
            if (existing == null) return false;
            _context.WorkingStatus.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }

    }
}