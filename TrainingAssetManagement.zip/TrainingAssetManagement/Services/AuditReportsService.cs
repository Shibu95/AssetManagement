using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class AuditReportsService
    {
        private readonly AppDbContext _context;
        public AuditReportsService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<int> CreateAuditReport(AuditReports entry)
        {
            _context.AuditReports.Add(entry);
            await _context.SaveChangesAsync();
            return entry.AuditEntryID;
        }

        public async Task<List<AuditReports>> GetAllReports()
        {
            return await _context.AuditReports.OrderByDescending(r => r.AuditEntryID).ToListAsync();
        }
        public async Task<AuditReports?> GetReportByAuditAndProduct(int auditId, int productId)
        {
            return await _context.AuditReports
                .FirstOrDefaultAsync(r => r.AuditID == auditId && r.ProductID == productId);
        }

        public async Task<List<AuditReports>> GetReportsByAuditId(int auditId)
        {
            return await _context.AuditReports.Where(r => r.AuditID == auditId).OrderByDescending(r => r.AuditedDate).ToListAsync();
        }
        public async Task<AuditReports?> GetReportByAuditAndAsset(int auditId, int productId)
        {
            return await _context.AuditReports.FirstOrDefaultAsync(r => r.AuditID == auditId && r.ProductID == productId);
        }

        public async Task<bool> DeleteAuditReportAsync(int id)
        {
            var existing = await _context.AuditReports.FindAsync(id);
            if (existing == null) return false;
            _context.AuditReports.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
