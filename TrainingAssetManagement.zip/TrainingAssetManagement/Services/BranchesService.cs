using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace TrainingAssetManagement.Services
{
    public class BranchesService
    {
        private readonly AppDbContext _context;
        public BranchesService(AppDbContext context)
        {
            _context = context;
        }
        public async Task<List<Branches>> GetAllBranches()
        {
            return await _context.Branches.ToListAsync();
        }

        public async Task<Branches> AddBranchAsync(Branches branch)
        {
            _context.Branches.Add(branch);
            await _context.SaveChangesAsync();
            return branch;
        }

        public async Task<bool> UpdateBranchAsync(Branches branch)
        {
            var existing = await _context.Branches.FindAsync(branch.BranchID);
            if (existing == null) return false;
            existing.BranchName = branch.BranchName;
            existing.AssetGroupID = branch.AssetGroupID;
            _context.Branches.Update(existing);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteBranchAsync(int branchId)
        {
            var existing = await _context.Branches.FindAsync(branchId);
            if (existing == null) return false;
            _context.Branches.Remove(existing);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}