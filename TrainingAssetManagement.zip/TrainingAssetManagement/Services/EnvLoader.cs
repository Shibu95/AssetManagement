namespace TrainingAssetManagement.Services;

public static class EnvLoader
{
    public static Dictionary<string, string> Load()
    {
        string root = AppContext.BaseDirectory;
        string envPath = Path.Combine(root, ".env");

        if (!File.Exists(envPath))
            throw new Exception("Could not find .env file at " + envPath);

        var dict = new Dictionary<string, string>();

        foreach (var line in File.ReadAllLines(envPath))
        {
            if (string.IsNullOrWhiteSpace(line) || line.StartsWith("#"))
                continue;

            var parts = line.Split('=', 2);

            if (parts.Length == 2)
                dict[parts[0].Trim()] = parts[1].Trim();
        }

        return dict;
    }
}