using Microsoft.EntityFrameworkCore;
using TrainingAssetManagement.Data;
using TrainingAssetManagement.Models;

namespace TrainingAssetManagement.Services
{
    public class AssetAllocationService
    {
        private readonly AppDbContext _context;

        public AssetAllocationService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<AssetAllocation>> GetAll()
        {
            return await _context.AssetAllocations
                .OrderByDescending(a => a.AssetAllocationID)
                .ToListAsync();
        }

        public async Task<AssetAllocation?> GetById(int id)
        {
            return await _context.AssetAllocations.FindAsync(id);
        }

        public async Task<int> Create(AssetAllocation model)
        {
            _context.AssetAllocations.Add(model);
            await _context.SaveChangesAsync();
            return model.AssetAllocationID;
        }

        public async Task Update(AssetAllocation model)
        {
            var existing = await _context.AssetAllocations.FindAsync(model.AssetAllocationID);
            if (existing == null) return;

            _context.Entry(existing).CurrentValues.SetValues(model);
            await _context.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var rec = await _context.AssetAllocations.FindAsync(id);
            if (rec == null) return;

            _context.AssetAllocations.Remove(rec);
            await _context.SaveChangesAsync();
        }

        public async Task AssignAsync(int productId, string assignedTo, string assignedBy)
        {
            // Create new allocation
            var allocation = new AssetAllocation
            {
                ProductID = productId,
                AssignedTo = assignedTo,
                AssignedBy = assignedBy,
                AssignedOn = DateTime.UtcNow,
                ReceivedOn = DateTime.SpecifyKind(DateTime.MinValue, DateTimeKind.Utc)
            };

            _context.AssetAllocations.Add(allocation);

            await _context.SaveChangesAsync();
        }
        public async Task RevokeAsync(int productId, string currentUser, string remarks)
        {
            var now = DateTime.UtcNow;

            // Find open allocation
            var openAllocation = await _context.AssetAllocations
                .FirstOrDefaultAsync(a =>
                    a.ProductID == productId &&
                    a.ReceivedOn == DateTime.MinValue);

            if (openAllocation != null)
            {
                openAllocation.ReceivedBy = currentUser;
                openAllocation.ReceivedOn = now;
                openAllocation.Remarks = remarks?.Trim();

                await _context.SaveChangesAsync();
            }
        }

        public async Task<List<AssetAllocation>> GetByProductId(int productId)
        {
            return await _context.AssetAllocations
                .Where(a => a.ProductID == productId)
                .OrderByDescending(a => a.AssignedOn)
                .ToListAsync();
        }

    }
}