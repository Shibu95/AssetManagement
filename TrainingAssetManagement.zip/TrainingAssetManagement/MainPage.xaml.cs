﻿namespace TrainingAssetManagement;

public partial class MainPage : ContentPage
{
	public MainPage()
	{
		InitializeComponent();
	}
}