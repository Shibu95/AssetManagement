function downloadFileFromBytes(filename, base64Data) {
    const link = document.createElement('a');
    link.download = filename;
    link.href = "data:application/octet-stream;base64," + base64Data;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function focusElementById(id) {
    try {
        const el = document.getElementById(id);
        if (el) {
            el.focus();
        }
    } catch { }
}

window.toggleSidebar = function () {
    try {
        document.body.classList.toggle('sidebar-collapsed');
    } catch (e) { }
}

window.registerSidebarResize = function (dotNetHelper) {
    try {
        function update() {
            const shouldCollapse = window.innerWidth <= 1300;

            if (shouldCollapse) {
                document.body.classList.add('sidebar-collapsed');
                dotNetHelper.invokeMethodAsync('SetCollapsedFromJs', true);
            }
        }

        window.addEventListener('resize', update);

        window._sidebar_resize_update = update;
        window._sidebar_dotnet = dotNetHelper;
    } catch { }
};

window.unregisterSidebarResize = function () {
    try {
        if (window._sidebar_resize_update) {
            window.removeEventListener('resize', window._sidebar_resize_update);
            window._sidebar_resize_update = null;
        }
        if (window._sidebar_dotnet) {
            try { window._sidebar_dotnet.dispose(); } catch { }
            window._sidebar_dotnet = null;
        }
    } catch (e) { }
}

// Returns the first page heading text found in the main article content
window.getPageTitle = function () {
    try {
        const content = document.querySelector('article.content');
        if (!content) return '';
        const heading = content.querySelector('h1,h2,h3');
        return heading ? heading.textContent.trim() : '';
    }
    catch { return ''; }
}

// Watch for changes inside the article content and notify .NET when title changes
window.registerTitleObserver = function (dotNetHelper) {
    try {
        const content = document.querySelector('article.content');
        if (!content) return;

        const observer = new MutationObserver(() => {
            try {
                const heading = content.querySelector('h1,h2,h3');
                const title = heading ? heading.textContent.trim() : '';
                dotNetHelper.invokeMethodAsync('UpdatePageTitle', title).catch(() => { });
            } catch { }
        });

        observer.observe(content, { childList: true, subtree: true, characterData: true });
        window._title_observer = observer;
        window._title_dotnet = dotNetHelper;
    } catch { }
}

window.unregisterTitleObserver = function () {
    try {
        if (window._title_observer) {
            window._title_observer.disconnect();
            window._title_observer = null;
        }
        if (window._title_dotnet) {
            try { window._title_dotnet.dispose(); } catch { }
            window._title_dotnet = null;
        }
    } catch { }
}

window.hideContentHeading = function () {
    try {
        const content = document.querySelector('article.content');
        if (!content) return;
        const heading = content.querySelector('h1,h2,h3,h4,h5,h6');
        if (!heading) return;
        // store original display if not already stored
        if (heading.dataset.__original_display === undefined) heading.dataset.__original_display = heading.style.display || '';
        heading.style.display = 'none';
    } catch { }
}

window.showContentHeading = function () {
    try {
        const content = document.querySelector('article.content');
        if (!content) return;
        const heading = content.querySelector('h1,h2,h3,h4,h5,h6');
        if (!heading) return;
        const orig = heading.dataset.__original_display;
        if (orig !== undefined) {
            heading.style.display = orig;
            delete heading.dataset.__original_display;
        } else {
            heading.style.removeProperty('display');
        }
    } catch { }
}

// let html5QrCode = null;

// window.startQrScanner = async (dotNetRef) => {

//     const reader = document.getElementById("reader");
//     if (!reader) return;

//     html5QrCode = new Html5Qrcode("reader");

//     const cameras = await Html5Qrcode.getCameras();
//     if (!cameras || cameras.length === 0) {
//         console.error("No camera found");
//         return;
//     }

//     // Always pick the first available camera (usually back camera)
//     const cameraId = cameras[0].id;

//     await html5QrCode.start(
//         cameraId,
//         { fps: 10, qrbox: { width: 250, height: 250 } },
//         (decodedText) => {
//             dotNetRef.invokeMethodAsync("OnQrScanned", decodedText);
//         },
//         (error) => console.debug(error)
//     );
// };

// window.stopQrScanner = async () => {
//     if (html5QrCode) {
//         await html5QrCode.stop();
//         await html5QrCode.clear();
//         html5QrCode = null;
//     }
// };



